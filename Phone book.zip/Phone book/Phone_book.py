# phone book
import PhoBookMod



# lets you select an option
def phone():
    
    # Shows the choices
    print("McDonald's")
    print()
    print("Edington Solicitors")
    print()
    print("Morinville Public Library")
    print()
    print("Luchka Trucking")
    print()
    print("Google Inc.")
    print()

    Phone = (input (":> "))

    if Phone == "McDonald's":
        print(PhoBookMod.Business1)

    elif Phone == "Edington Solicitors":
        print(PhoBookMod.Business2)

    elif Phone == "Morinville Public Library":
        print(PhoBookMod.Business3)

    elif Phone == "Luchka Trucking":
        print(PhoBookMod.Business4)

    elif Phone == "Google Inc.":
        print(PhoBookMod.Business5)

    # If you do not enter a correct option
    else:
        print("This choice does not exist")
    
    phone()

phone()

# Goodbye message
print("Thankyou, Goodbye")


    


