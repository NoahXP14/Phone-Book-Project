Phonebook Project:

    there are 3 files total:
        1. Phone_book Which is the main document that the program will be ran in
        2. PhoBookMod whis is the module containing all the Contact information
        3. Readme whis is this document
    
    The key words that the program output uses:
        Name:
            Displays the name of the business
        Address:
            Displays the address of the business
        Phone:
            Displays the phone number
        Fax:
            Displays the fax number (if applicable)
    
    Inputs that you should put in the command line:
        McDonalds
        Edington Solicitors
        Morinville Public Library
        Luchka Trucking
        Google Inc.
    
    Output:
        The program will output the requestid information in the order:
            Name:
            Address:
            Phone:
            Fax: (if applicable)
