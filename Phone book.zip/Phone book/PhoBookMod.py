#Phone book

# McDonald's
Business1 = """
    Name: McDonald's
    Address: 16253 63st, Edmonton
    Phone: (780) 563-8217
    """

# Edington Solicitors
Business2 = """
    Name: Edington Solicitors
    Address: 88 High Street, Brighton
    Phone: +0 (189) 675-6161
    Fax: +0 (189) 675-1919
    """

# Morinville Public Library
Business3 = """
    Name: Morinville Public Library
    Address: 10125 100Ave, Morinville
    Phone: (780) 939-3292
    """

# Luchka Trucking
Business4 = """
    Name: Luchka Trucking
    Address: 172 N Port Rd, Port Perry
    Phone: +1 (905) 985-9425
    """

# Google Inc.
Business5 = """
    Name: Google Inc.
    Address: 1600 Amphitheatre Pkwy, Mountain View
    Phone: +1 (650) 253-0000
    """
